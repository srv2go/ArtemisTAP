import React from 'react'
import TransitionPlatform from './components/TransitionPlatform'

function App() {
  return <TransitionPlatform />
}

export default App
